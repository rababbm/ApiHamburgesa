package com.example.servingwebcontent;//package com.example.servingwebcontent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record ApiQuote(String name, double calories, double servingSizeG){
}
