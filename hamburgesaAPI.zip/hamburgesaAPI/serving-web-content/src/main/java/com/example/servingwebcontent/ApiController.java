package com.example.servingwebcontent;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class ApiController {

    @GetMapping("/apiInfo")
    public String mostrarApiInfo(Model model) {
        List<ApiInfo> apiInfoList = obtenerDatosDeLaApi();
        model.addAttribute("apiInfoList", apiInfoList);
        return "apiHamburgesa";
    }

    private List<ApiInfo> obtenerDatosDeLaApi() {
        return Arrays.asList(
                new ApiInfo("brisket", 1312.3, 453.592, 82.9, 33.2, 132, 217, 781, 487, 0, 0, 0),
                new ApiInfo("fries", 317.7, 100, 14.8, 2.3, 3.4, 212, 124, 0, 41.1, 3.8, 0.3)
        );
    }
}
