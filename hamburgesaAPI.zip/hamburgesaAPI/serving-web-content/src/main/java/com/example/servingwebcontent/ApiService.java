package com.example.servingwebcontent;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ApiService {
    private final String apiUrl = "https://nutrition-by-api-ninjas.p.rapidapi.com/...";

    private final RestTemplate restTemplate;

    public ApiService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ApiInfo getApiInfo() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-RapidAPI-Key", "c32569032fmsh7bfd49b666db41fp16710ejsncb2e72b61e0c");
        headers.set("X-RapidAPI-Host", "nutrition-by-api-ninjas.p.rapidapi.com");
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Puedes agregar otras cabeceras según sea necesario

        // Realizar la solicitud con las cabeceras
        ApiInfo apiInfo = restTemplate.getForObject(
                apiUrl,
                ApiInfo.class,
                headers
        );
        return apiInfo;
    }
}
